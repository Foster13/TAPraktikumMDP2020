    import livi from './livi.png'
    import nice from './nice.png'
    import paseo from './paseo.png'
    import tessa from './tessa.png'
    import toply from './Toply.png'

    export {
        livi,
        nice,
        paseo,
        tessa,
        toply
    }